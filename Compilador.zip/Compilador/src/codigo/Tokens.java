/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package codigo;

/**
 *
 * @author miran
 */
public enum Tokens {
    Org,
    Fcb,
    End,
    Equ,
    Linea,
    Espacio,
    Comentario,
    Etiq_Var_Instrucc,
    EtiqIMM,
    HexaExtOrgEqu,
    NumeroHexaIMM,
    NumeroDecIMM,
    CharIMM,
    NumeroHexaDIR,
    NumeroDecDIR,
    NumeroDIR,
    NumeroDecEXT,
    NumeroDecEXT_DIR,
    NumeroHexaEXT,
    NumeroHexaINDX,
    NumeroINDX,
    NumeroHexaINDY,
    NumeroINDY,
    NumFCB,
    ERROR
}
