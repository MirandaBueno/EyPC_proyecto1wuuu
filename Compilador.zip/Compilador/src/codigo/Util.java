/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Hashtable;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author miran
 */
public class Util {
    Hashtable<String,Instr> IMM;
    Hashtable<String,Instr> INDX;
    Hashtable<String,Instr> INDY;
    Hashtable<String,Instr> DIR;
    Hashtable<String,Instr> EXT;
    Hashtable<String,Instr> REL;
    Hashtable<String,Instr> INH;
    
    public Util(){
        imm();
        ext();
        inh();
        dir();
        indx();
        indy();
        rel();
    }
    
    public void imm(){
        Hashtable<String,Instr> IMM=new Hashtable<String,Instr>();
        IMM.put("ADCA",new Instr("89",2,1));
        IMM.put("ADCB",new Instr("C9",2,1));
        IMM.put("ADDA",new Instr("8B",2,1));
        IMM.put("ADDB",new Instr("CB",2,1));
        IMM.put("ADDD",new Instr("C3",3,2));
        IMM.put("ANDA",new Instr("84",2,1));
        IMM.put("ANDA",new Instr("C4",2,1));
        IMM.put("BITA",new Instr("85",2,1));
        IMM.put("BITB",new Instr("C5",2,1));
        IMM.put("CMPA",new Instr("81",2,1));
        IMM.put("CMPB",new Instr("C1",2,1));
        IMM.put("CPD",new Instr("1A83",4,2));
        IMM.put("CPX",new Instr("8C",3,2));
        IMM.put("CPY",new Instr("188C",4,2));
        IMM.put("EORA",new Instr("88",2,1));
        IMM.put("EORB",new Instr("C8",2,1));
        IMM.put("LDAA",new Instr("86",2,1));
        IMM.put("LDAB",new Instr("C6",2,1));
        IMM.put("LDD",new Instr("CC",3,2));
        IMM.put("LDS",new Instr("8E",3,2));
        IMM.put("LDX",new Instr("CE",3,2));
        IMM.put("LDY",new Instr("18CE",4,2));
        IMM.put("ORAA",new Instr("8A",2,1));
        IMM.put("ORAB",new Instr("CA",2,1));
        IMM.put("SBCA",new Instr("82",2,1));
        IMM.put("SBCB",new Instr("C2",2,1));
        IMM.put("SUBA",new Instr("80",2,1));
        IMM.put("SUBB",new Instr("C0",2,1));
        IMM.put("SUBD",new Instr("83",3,2));
        this.IMM=IMM;
    }
    
    public void ext(){
        Hashtable<String,Instr> EXT=new Hashtable<String,Instr>();
        EXT.put("ADCA",new Instr("B9",3,2));
        EXT.put("ADCB",new Instr("F9",3,2));
        EXT.put("ADDA",new Instr("BB",3,2));
        EXT.put("ADDB",new Instr("FB",3,2));
        EXT.put("ADDD",new Instr("F3",3,2));
        EXT.put("ANDA",new Instr("B4",3,2));
        EXT.put("ANDB",new Instr("F4",3,2));
        EXT.put("ASL",new Instr("78",3,2));
        EXT.put("ASR",new Instr("77",3,2));
        EXT.put("BITA",new Instr("B5",3,2));
        EXT.put("BITB",new Instr("F5",3,2));
        EXT.put("CLR",new Instr("7F",3,2));
        EXT.put("CMPA",new Instr("B1",3,2));
        EXT.put("CMPB",new Instr("F1",3,2));
        EXT.put("COM",new Instr("73",3,2));
        EXT.put("CPD",new Instr("1AB3",4,2));
        EXT.put("CPX",new Instr("BC",3,2));
        EXT.put("CPY",new Instr("18BC",4,2));
        EXT.put("DEC",new Instr("7A",3,2));
        EXT.put("EORA",new Instr("B8",3,2));
        EXT.put("EORB",new Instr("F8",3,2));
        EXT.put("INC",new Instr("7C",3,2));
        EXT.put("JMP",new Instr("7E",3,2));
        EXT.put("JSR",new Instr("BD",3,2));
        EXT.put("LDAA",new Instr("B6",3,2));
        EXT.put("LDAB",new Instr("F6",3,2));
        EXT.put("LDD",new Instr("FC",3,2));
        EXT.put("LDS",new Instr("BE",3,2));
        EXT.put("LDX",new Instr("FE",3,2));
        EXT.put("LDY",new Instr("18FE",4,2));
        EXT.put("LSL",new Instr("78",3,2));
        EXT.put("LSR",new Instr("74",3,2));
        EXT.put("NEG",new Instr("70",3,2));
        EXT.put("ORAA",new Instr("BA",3,2));
        EXT.put("ORAB",new Instr("FA",3,2));
        EXT.put("ROL",new Instr("79",3,2));
        EXT.put("ROR",new Instr("76",3,2));
        EXT.put("SBCA",new Instr("B2",3,2));
        EXT.put("SBCB",new Instr("F2",3,2));
        EXT.put("STAA",new Instr("B7",3,2));
        EXT.put("STAB",new Instr("F7",3,2));
        EXT.put("STD",new Instr("FD",3,2));
        EXT.put("STS",new Instr("BF",3,2));
        EXT.put("STX",new Instr("FF",3,2));
        EXT.put("STY",new Instr("18FF",4,2));
        EXT.put("SUBA",new Instr("B0",3,2));
        EXT.put("SUBB",new Instr("F0",3,2));
        EXT.put("SUBD",new Instr("B3",3,2));
        EXT.put("TST",new Instr("7D",3,2));
        this.EXT=EXT;
    }
    
    public void dir(){
        Hashtable<String,Instr> DIR=new Hashtable<String,Instr>();
        DIR.put("ADCA",new Instr("99",2,1));
        DIR.put("ADCB",new Instr("D9",2,1));
        DIR.put("ADDA",new Instr("9B",2,1));
        DIR.put("ADDB",new Instr("DB",2,1));
        DIR.put("ADDD",new Instr("D3",2,1));
        DIR.put("ANDA",new Instr("94",2,1));
        DIR.put("ANDB",new Instr("D4",2,1));
        DIR.put("BCLR",new Instr("15",3,2));
        DIR.put("BITA",new Instr("95",2,1));
        DIR.put("BITB",new Instr("D5",2,1));
        DIR.put("BRCLR",new Instr("13",4,3));
        DIR.put("BRSET",new Instr("12",4,3));
        DIR.put("BSET",new Instr("14",3,2));
        DIR.put("CMPA",new Instr("91",2,1));
        DIR.put("CMPB",new Instr("D1",2,1));
        DIR.put("CPD",new Instr("1A93",3,1));
        DIR.put("CPX",new Instr("9C",2,1));
        DIR.put("CPY",new Instr("189C",3,1));
        DIR.put("EORA",new Instr("98",2,1));
        DIR.put("EORB",new Instr("D8",2,1));
        DIR.put("JSR",new Instr("9D",2,1));
        DIR.put("LDAA",new Instr("96",2,1));
        DIR.put("LDAB",new Instr("D6",2,1));
        DIR.put("LDD",new Instr("DC",2,1));
        DIR.put("LDS",new Instr("9E",2,1));
        DIR.put("LDX",new Instr("DE",2,1));
        DIR.put("LDY",new Instr("18DE",3,1));
        DIR.put("ORAA",new Instr("9A",2,1));
        DIR.put("ORAB",new Instr("DA",2,1));
        DIR.put("SBCA",new Instr("92",2,1));
        DIR.put("SBCB",new Instr("D2",2,1));
        DIR.put("STAA",new Instr("97",2,1));
        DIR.put("STAB",new Instr("D7",2,1));
        DIR.put("STD",new Instr("DD",2,1));
        DIR.put("STS",new Instr("9F",2,1));
        DIR.put("STX",new Instr("DF",2,1));
        DIR.put("STY",new Instr("18DF",3,1));
        DIR.put("SUBA",new Instr("90",2,1));
        DIR.put("SUBB",new Instr("D0",2,1));
        DIR.put("SUBD",new Instr("93",2,1));
        
        this.DIR=DIR;
    }
    public void inh(){
        Hashtable<String,Instr> INH=new Hashtable<String,Instr>();
        INH.put("ABA",new Instr("1B",1,0));
        INH.put("ABX",new Instr("3A",1,0));
        INH.put("ABY",new Instr("183A",2,0));
        INH.put("ASLA",new Instr("48",1,0));
        INH.put("ASLB",new Instr("58",1,0));
        INH.put("ASLD",new Instr("05",1,0));
        INH.put("ASRA",new Instr("47",1,0));
        INH.put("ASRB",new Instr("57",1,0));
        INH.put("CBA",new Instr("11",1,0));
        INH.put("CLC",new Instr("0C",1,0));
        INH.put("CLI",new Instr("0E",1,0));
        INH.put("CLRA",new Instr("4F",1,0));
        INH.put("CLRB",new Instr("5F",1,0));
        INH.put("CLV",new Instr("0A",1,0));
        INH.put("COMA",new Instr("43",1,0));
        INH.put("COMB",new Instr("53",1,0));
        INH.put("DAA",new Instr("19",1,0));
        INH.put("DECA",new Instr("4A",1,0));
        INH.put("DECB",new Instr("5A",1,0));
        INH.put("DES",new Instr("34",1,0));
        INH.put("DEX",new Instr("09",1,0));
        INH.put("DEY",new Instr("1809",2,0));
        INH.put("FDIV",new Instr("03",1,0));
        INH.put("IDIV",new Instr("02",1,0));
        INH.put("INCA",new Instr("4C",1,0));
        INH.put("INCB",new Instr("5C",1,0));
        INH.put("INS",new Instr("31",1,0));
        INH.put("INX",new Instr("08",1,0));
        INH.put("INY",new Instr("1808",2,0));
        INH.put("LSLA",new Instr("48",1,0));
        INH.put("LSLB",new Instr("58",1,0));
        INH.put("LSLD",new Instr("05",1,0));
        INH.put("LSRA",new Instr("44",1,0));
        INH.put("LSRB",new Instr("54",1,0));
        INH.put("LSRD",new Instr("04",1,0));
        INH.put("MUL",new Instr("3D",1,0));
        INH.put("NEGA",new Instr("40",1,0));
        INH.put("NEGB",new Instr("50",1,0));
        INH.put("NOP",new Instr("01",1,0));
        INH.put("PSHA",new Instr("36",1,0));
        INH.put("PSHB",new Instr("37",1,0));
        INH.put("PSHX",new Instr("3C",1,0));
        INH.put("PSHY",new Instr("183C",2,0));
        INH.put("PULA",new Instr("32",1,0));
        INH.put("PULB",new Instr("33",1,0));
        INH.put("PULX",new Instr("38",1,0));
        INH.put("PULY",new Instr("1838",2,0));
        INH.put("ROLA",new Instr("49",1,0));
        INH.put("ROLB",new Instr("59",1,0));
        INH.put("RORA",new Instr("46",1,0));
        INH.put("RORB",new Instr("56",1,0));
        INH.put("RTI",new Instr("3B",1,0));
        INH.put("RTS",new Instr("39",1,0));
        INH.put("SBA",new Instr("10",1,0));
        INH.put("SEC",new Instr("0D",1,0));
        INH.put("SEI",new Instr("0F",1,0));
        INH.put("SEV",new Instr("0B",1,0));
        INH.put("STOP",new Instr("CF",1,0));
        INH.put("SWI",new Instr("3F",1,0));
        INH.put("TAB",new Instr("16",1,0));
        INH.put("TAP",new Instr("06",1,0));
        INH.put("TBA",new Instr("17",1,0));
        INH.put("TETS",new Instr("00",1,0));
        INH.put("TPA",new Instr("07",1,0));
        INH.put("TSTA",new Instr("4D",1,0));
        INH.put("TSTB",new Instr("5D",1,0));
        INH.put("TSX",new Instr("30",1,0));
        INH.put("TSY",new Instr("1830",2,0));
        INH.put("TXS",new Instr("35",1,0));
        INH.put("TYS",new Instr("1835",2,0));
        INH.put("WAI",new Instr("3E",1,0));
        INH.put("XGDX",new Instr("8F",1,0));
        INH.put("XGDY",new Instr("188F",2,0));
        this.INH=INH;
    }
    
    public void indx(){
        Hashtable<String,Instr> INDX=new Hashtable<String,Instr>();
        INDX.put("ADCA",new Instr("A9",2,1));
        INDX.put("ADCB",new Instr("E9",2,1));
        INDX.put("ADDA",new Instr("AB",2,1));
        INDX.put("ADDB",new Instr("EB",2,1));
        INDX.put("ADDD",new Instr("E3",2,1));
        INDX.put("ANDA",new Instr("B4",2,1));
        INDX.put("ANDB",new Instr("E4",2,1));
        INDX.put("ASL",new Instr("68",2,1));
        INDX.put("ASR",new Instr("67",2,1));
        INDX.put("BCLR",new Instr("1D",3,2));
        INDX.put("BITA",new Instr("A5",2,1));
        INDX.put("BITB",new Instr("E5",2,1));
        INDX.put("BRCLR",new Instr("1F",4,3));
        INDX.put("BRSET",new Instr("1E",4,3));
        INDX.put("BSET",new Instr("1C",3,2));
        INDX.put("CLR",new Instr("6F",2,1));
        INDX.put("CMPA",new Instr("A1",2,1));
        INDX.put("CMPB",new Instr("E1",2,1));
        INDX.put("COM",new Instr("63",2,1));
        INDX.put("CPD",new Instr("1AA3",3,1));
        INDX.put("CPX",new Instr("AC",2,1));
        INDX.put("CPY",new Instr("1AAC",3,1));
        INDX.put("DEC",new Instr("6A",2,1));
        INDX.put("EORA",new Instr("A8",2,1));
        INDX.put("EORB",new Instr("E8",2,1));
        INDX.put("INC",new Instr("6C",2,1));
        INDX.put("JMP",new Instr("6E",2,1));
        INDX.put("JSR",new Instr("AD",2,1));
        INDX.put("LDAA",new Instr("A6",2,1));
        INDX.put("LDAB",new Instr("E6",2,1));
        INDX.put("LDD",new Instr("EC",2,1));
        INDX.put("LDS",new Instr("AE",2,1));
        INDX.put("LDX",new Instr("EE",2,1));
        INDX.put("LDY",new Instr("1AEE",3,1));
        INDX.put("LSL",new Instr("68",2,1));
        INDX.put("LSR",new Instr("64",2,1));
        INDX.put("NEG",new Instr("60",2,1));
        INDX.put("ORAA",new Instr("AA",2,1));
        INDX.put("ORAB",new Instr("EA",2,1));
        INDX.put("ROL",new Instr("69",2,1));
        INDX.put("ROR",new Instr("66",2,1));
        INDX.put("SBCA",new Instr("A2",2,1));
        INDX.put("SBCB",new Instr("E2",2,1));
        INDX.put("STAA",new Instr("A7",2,1));
        INDX.put("STAB",new Instr("E7",2,1));
        INDX.put("STD",new Instr("ED",2,1));
        INDX.put("STS",new Instr("AF",2,1));
        INDX.put("STX",new Instr("EF",2,1));
        INDX.put("STY",new Instr("1AEF",3,1));
        INDX.put("SUBA",new Instr("A0",2,1));
        INDX.put("SUBB",new Instr("E0",2,1));
        INDX.put("SUBD",new Instr("A3",2,1));
        INDX.put("TST",new Instr("6D",2,1));
        this.INDX=INDX;
    }
    public void indy(){
        Hashtable<String,Instr> INDY=new Hashtable<String,Instr>();
        INDY.put("ADCA",new Instr("18A9",3,1));
        INDY.put("ADCB",new Instr("18E9",3,1));
        INDY.put("ADDA",new Instr("18AB",3,1));
        INDY.put("ADDB",new Instr("18EB",3,1));
        INDY.put("ADDD",new Instr("18E3",3,1));
        INDY.put("ANDA",new Instr("18A4",3,1));
        INDY.put("ANDB",new Instr("18E4",3,1));
        INDY.put("ASL",new Instr("1868",3,1));
        INDY.put("ASR",new Instr("1867",3,1));
        INDY.put("BCLR",new Instr("181D",4,2));
        INDY.put("BITA",new Instr("18A5",3,1));
        INDY.put("BITB",new Instr("18E5",3,1));
        INDY.put("BRCLR",new Instr("181F",5,3));
        INDY.put("BRSET",new Instr("181E",5,3));
        INDY.put("BSET",new Instr("181C",4,2));
        INDY.put("CLR",new Instr("186F",3,1));
        INDY.put("CMPA",new Instr("18A1",3,1));
        INDY.put("CMPB",new Instr("18E1",3,1));
        INDY.put("COM",new Instr("1863",3,1));
        INDY.put("CPD",new Instr("CDA3",3,1));
        INDY.put("CPX",new Instr("CDAC",3,1));
        INDY.put("CPY",new Instr("18AC",3,1));
        INDY.put("DEC",new Instr("186A",3,1));
        INDY.put("EORA",new Instr("18A8",3,1));
        INDY.put("EORB",new Instr("18E8",3,1));
        INDY.put("INC",new Instr("186C",3,1));
        INDY.put("JMP",new Instr("186E",3,1));
        INDY.put("JSR",new Instr("18AD",3,1));
        INDY.put("LDAA",new Instr("18A6",3,1));
        INDY.put("LDAB",new Instr("18E6",3,1));
        INDY.put("LDD",new Instr("18EC",3,1));
        INDY.put("LDS",new Instr("18AE",3,1));
        INDY.put("LDX",new Instr("CDEE",3,1));
        INDY.put("LDY",new Instr("18EE",3,1));
        INDY.put("LSL",new Instr("1868",3,1));
        INDY.put("LSR",new Instr("1864",3,1));
        INDY.put("NEG",new Instr("1860",3,1));
        INDY.put("ORAA",new Instr("18AA",3,1));
        INDY.put("ORAB",new Instr("18EA",3,1));
        INDY.put("ROL",new Instr("1869",3,1));
        INDY.put("ROR",new Instr("1866",3,1));
        INDY.put("SBCA",new Instr("18A2",3,1));
        INDY.put("SBCB",new Instr("18E2",3,1));
        INDY.put("STAA",new Instr("18A7",3,1));
        INDY.put("STAB",new Instr("18E7",3,1));
        INDY.put("STD",new Instr("18ED",3,1));
        INDY.put("STS",new Instr("18AF",3,1));
        INDY.put("STX",new Instr("CDEF",3,1));
        INDY.put("STY",new Instr("18EF",3,1));
        INDY.put("SUBA",new Instr("18A0",3,1));
        INDY.put("SUBB",new Instr("18E0",3,1));
        INDY.put("SUBD",new Instr("18A3",3,1));
        INDY.put("TST",new Instr("186D",3,1));
        this.INDY=INDY;
    }
    
    public void rel(){
        Hashtable<String,Instr> REL=new Hashtable<String,Instr>();
        REL.put("BCC",new Instr("24",2,1));
        REL.put("BCS",new Instr("25",2,1));
        REL.put("BEQ",new Instr("27",2,1));
        REL.put("BGE",new Instr("2C",2,1));
        REL.put("BGT",new Instr("2E",2,1));
        REL.put("BHI",new Instr("22",2,1));
        REL.put("BHS",new Instr("24",2,1));
        REL.put("BLE",new Instr("2F",2,1));
        REL.put("BLO",new Instr("25",2,1));
        REL.put("BLS",new Instr("23",2,1));
        REL.put("BLT",new Instr("2D",2,1));
        REL.put("BMI",new Instr("2B",2,1));
        REL.put("BNE",new Instr("26",2,1));
        REL.put("BPL",new Instr("2A",2,1));
        REL.put("BRA",new Instr("20",2,1));
        REL.put("BRN",new Instr("21",2,1));
        REL.put("BSR",new Instr("8D",2,1));
        REL.put("BVC",new Instr("28",2,1));
        REL.put("BVS",new Instr("29",2,1));
        this.REL=REL;
    }
    
    public Instr buscarOpREL(String mnem){
        return this.REL.get(mnem);
    }
    public Instr buscarOpINDY(String mnem){
        return this.INDY.get(mnem);
    }
    public Instr buscarOpINDX(String mnem){
        return this.INDX.get(mnem);
    }
    public Instr buscarOpIMM(String mnem){
        return this.IMM.get(mnem);
    }
    public Instr buscarOpEXT(String mnem){
        return this.EXT.get(mnem);
    }
    public Instr buscarOpDIR(String mnem){
        return this.DIR.get(mnem);
    }
    public Instr buscarOpINH(String mnem){
        return this.INH.get(mnem);
    }
    
//    
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM": 
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
//                                        code[3].substring(2)+") \t");
//                                if(code[3].substring(2).length()<4)
//                                    lst.write("");
//                                lst.write(":\t");
//                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
//                                        DecAHexaIMM(code[3],util.buscarOpIMM(mnem).getOpBy())+
//                                        ")\t:\t");
//                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
//                                        CharAHexaIMM(code[3])+")\t:\t");
//                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                sub=code[3];
////                                System.out.println("entroo");
////                                System.out.println(mnem);
////                                System.out.println(sub);
//                                if(util.buscarOpIMM(mnem)!=null){
//                                    if(Equ.get(sub)!=null){
//                                        lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
//                                                Equ.get(sub)+")\t\t:\t");
//                                        loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                                    }else{
////                                        pendiente.put(sub,cont);
//                                    }
//                                }else{
//                                    
//                                }
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                                break;
//
//                    // DIR**********************************************************************
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_OMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT_ESPACIO_COMENTARIO":
//                                
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT_ESPACIO_COMENTARIO":
//                                break;
//
//                     // EXT *******************************************************************
//
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//                                break;
//                                
//         // INDX Y *************************************************************
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
//                                break;
//
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
//                                break;
//
//                       // EXT ETIQUETA
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                var=code[3];
//                                mnem=code[1];
//                                if(Equ.get(var)!=null){
//                                    if((util.buscarOpEXT(mnem)!=null)&&(Integer.parseInt((String)Equ.get(var),16)>255)){
//                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
//                                        Equ.get(var)+")\t:\t");
//                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//
//                                    }else if((util.buscarOpDIR(mnem)!=null)&&(Integer.parseInt((String)Equ.get(var),16)<256)){
//                                        operando=(String)Equ.get(var);
//                                        lst.write(cont+": "+loc+" ("+util.buscarOpDIR(mnem).getOp()+
//                                        operando.substring(2)+")\t:\t");
//                                        this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
//                                    }else if(util.buscarOpEXT(mnem)!=null){
//                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
//                                        Equ.get(var)+")\t:\t");
//                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//                                    }
//                                }else if(Subr.get(var)!=null){
//                                    if(util.buscarOpEXT(mnem)!=null){
//                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
//                                                Subr.get(var)+")\t:\t");
//                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//                                    }else if(util.buscarOpREL(mnem)!=null){
//                                        if(Integer.parseInt(Subr.get(var),16)<Integer.parseInt(loc,16)){
//                                            rel=Integer.parseInt(localidad(loc,util.buscarOpREL(mnem).getBy()),16)-Integer.parseInt(Subr.get(var),16)-1;
//                                            System.out.println("var:"+var);
//                                            System.out.println("mnem:"+mnem);
//                                            System.out.println("loc:"+Integer.parseInt(localidad(loc,1),16)+8);
//                                            System.out.println("loc:"+localidad(loc,util.buscarOpREL(mnem).getBy()));
//                                            System.out.println("sub:"+Integer.parseInt(Subr.get(var),16));
//                                            System.out.println("sub:"+Subr.get(var));
//                                            bin=Integer.toBinaryString(rel);
//                                            System.out.println("rel:"+rel);
//                                            System.out.println("bin:"+bin);
//                                            
//                                            bin=complemento2(bin);
//                                            System.out.println("bin:"+bin);
//                                            lst.write(cont+": "+loc+" ("+util.buscarOpREL(mnem).getOp()+
//                                                bin.toUpperCase()+")\t:\t");
//                                            this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());
//                                        }
//                                    }
//                                }
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                var=code[4];
//                                mnem=code[2];
//                                if(Equ.get(var)!=null){
//                                    if((util.buscarOpEXT(mnem)!=null)){
//                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
//                                        Equ.get(var)+")\t:\t");
//                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//
//                                    }
//                                }else if(Subr.get(var)!=null){
//                                    if(util.buscarOpEXT(mnem)!=null){
////                                        System.out.println(">>"+cont+">>"+var+">>"+Subr.get(var));
//                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
//                                                Subr.get(var)+")\t:\t");
//                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//                                    }else if(util.buscarOpREL(mnem)!=null){
//                                        System.out.println(mnem);
//                                        System.out.println(var);
//                                        lst.write(cont+": "+loc+" ("+util.buscarOpREL(mnem).getOp()+
//                                                Subr.get(var)+")\t:\t");
//                                        this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());
//                                    }
//                                }else{
////                                    System.out.println("2");
//                                }
////                                System.out.println("3"+var+mnem);
//                                break;
//
//                   // INH
//                            case "ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                mnem=code[1];
//                               // System.out.println(mnem);
//                                lst.write(cont+": "+loc+" ("+util.buscarOpINH(mnem).getOp()+")\t\t:\t");
//                                this.loc=localidad(loc,util.buscarOpINH(mnem).getBy());
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                mnem=code[2];
//                                this.loc=localidad(loc,util.buscarOpINH(mnem).getBy());
//                                break;
//
//                    // EQU ETIQUETAS **********************************************************
//
//                            case "ET.VAR.MNEM.SUB_ESPACIO_EQU_ESPACIO_H.ORG.EQU.EXT":
//                                lst.write(cont+": \t"+code[4].substring(1)+"\t\t:\t");
//                                Equ.put(code[0], code[4].substring(1));
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_EQU_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
//                                lst.write(cont+": \t"+code[4].substring(1)+"\t\t:\t");
//                                Equ.put(code[0], code[4].substring(1));
//                                break;
//
//                    // ORG *******************************************************************
//                            case "ESPACIO_ORG_ESPACIO_H.ORG.EQU.EXT":
//                            case "ESPACIO_ORG_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
//                                lst.write(cont+": \t("+code[3].substring(1)+")\t\t:\t");
//                                break;
//
//                    // subrut ****************************************************************
//                            case "ET.VAR.MNEM.SUB":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                sub=code[0];
//                                
//                                    //Subr.put(sub,loc);
//                                    lst.write(cont+": "+loc+"\t\t:\t");
//                                
//                                break;
//                            
//                            case "ESPACIO_FCB_ESPACIO_H.FCB":
//                            case "ESPACIO_FCB_ESPACIO_H.FCB_ESPACIO_COMENTARIO":
//                                break;
//                            case "ET.VAR.MNEM.SUB_ESPACIO_FCB_ESPACIO_H.FCB":
//                            case "ET.VAR.MNEM.SUB_ESPACIO_FCB_ESPACIO_H.FCB_ESPACIO_COMENTARIO":
//                                break;
//
//                            case "ESPACIO_END_ESPACIO_H.ORG.EQU.EXT":
//                                break;


}
