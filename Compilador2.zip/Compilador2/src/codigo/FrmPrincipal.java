/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package codigo;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.nio.file.Files;
import java.util.logging.Level;
import java.util.logging.Logger;
import java_cup.runtime.Symbol;
import javax.swing.JFileChooser;

/**
 *
 * @author miran
 */
public class FrmPrincipal extends javax.swing.JFrame {

    /**
     * Creates new form FrmPrincipal
     */
    public FrmPrincipal() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    private void analizarLexico() throws IOException{
        int cont=1;
        String loc="8000";
        String operando;
        String opCode;
        String mascara;
        int end=0;
        String expr=(String)txtResultado.getText();
        Lexer lexer =new Lexer(new StringReader(expr));
        String resultado="  "+cont+": ";
        while(true){
            Tokens token=lexer.yylex();
            if(token==null){
                txtAnalizarLex.setText(resultado);
                return;
            }
            switch (token) {
                case Linea:
                    cont++;
                    if(cont<10){
                        resultado +="\n  "+  cont + ": ";
                    }else if(cont<100){
                        resultado +="\n "+  cont + ": ";
                    }else
                        resultado +="\n"+  cont + ": ";
                    
                    break;
                case Comentario:
                    resultado+=" \t\t\t"+lexer.lexeme;
                    break;
                case Gato:
                    resultado += "  " + lexer.lexeme + "\n";
                    break;
                case Apostrofe:
                    resultado += "  <Apostrofe>\t" + lexer.lexeme + "\n";
                    break;
                case SignoPeso:
                    resultado += "  " + lexer.lexeme; //+ "\n";
                    break;
                case ORG:
                    operando=operandoH4(lexer.lexeme);
                    resultado+="           ("+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                    break;
                case EQU:
                    operando=operandoH4(lexer.lexeme);
                    resultado+="           ("+operando+")\t : \t"+lexer.lexeme.stripLeading().toUpperCase();
                    break;
                case END:
                    end++;
                    if(end>1)
                        System.out.println(" error");
                    break;
                case Opcode:
                    resultado += "  <Opcode>\t" + lexer.lexeme + "\n";
                    break;
                case DosPuntos:
                    resultado += "  <:>\t" + lexer.lexeme + "\n";
                    break;
                case Otro:
                    resultado += "  <Otro>\t" + lexer.lexeme + "\n";
                    break;
                case INH_ABA:
                    resultado+=loc+" (1B)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_ABX:
                    resultado+=loc+" (3A)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_ABY:
                    resultado+=loc+" (183A)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case INH_ASLA:
                    resultado+=loc+" (48)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_ASLB:
                    resultado+=loc+" (58)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_ASLD:
                    resultado+=loc+" (05)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_ASRA:
                    resultado+=loc+" (47)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_ASRB:
                    resultado+=loc+" (57)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_CBA:
                    resultado+=loc+" (11)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_CLC:
                    resultado+=loc+" (0C)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_CLI:
                    resultado+=loc+" (0E)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_CLRA:
                    resultado+=loc+" (4F)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_CLRB:
                    resultado+=loc+" (5F)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_CLV:
                    resultado+=loc+" (0A)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_COMA:
                    resultado+=loc+" (43)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_COMB:
                    resultado+=loc+" (53)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_DAA:
                    resultado+=loc+" (19)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_DECA:
                    resultado+=loc+" (4A)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_DECB:
                    resultado+=loc+" (5A)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_DES:
                    resultado+=loc+" (34)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_DEX:
                    resultado+=loc+" (09)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_DEY:
                    resultado+=loc+" (1809)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case INH_FDIV:
                    resultado+=loc+" (03)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_IDIV:
                    resultado+=loc+" (02)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_INCA:
                    resultado+=loc+" (4C)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_INCB:
                    resultado+=loc+" (5C)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_INS:
                    resultado+=loc+" (31)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_INX:
                    resultado+=loc+" (08)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_INY:
                    resultado+=loc+" (1808)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case INH_LSLA:
                    resultado+=loc+" (48)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_LSLB:
                    resultado+=loc+" (58)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_LSLD:
                    resultado+=loc+" (05)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_LSRA:
                    resultado+=loc+" (44)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_LSRB:
                    resultado+=loc+" (54)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_LSRD:
                    resultado+=loc+" (04)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_MUL:
                    resultado+=loc+" (3D)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break; 
                case INH_NEGA:
                    resultado+=loc+" (40)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_NEGB:
                    resultado+=loc+" (50)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_NOP:
                    resultado+=loc+" (01)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_PSHA:
                    resultado+=loc+" (36)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_PSHB:
                    resultado+=loc+" (37)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_PSHX:
                    resultado+=loc+" (3C)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_PSHY:
                    resultado+=loc+" (183C)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case INH_PULA:
                    resultado+=loc+" (32)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_PULB:
                    resultado+=loc+" (33)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_PULX:
                    resultado+=loc+" (38)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_PULY:
                    resultado+=loc+" (1838)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case INH_ROLA:
                    resultado+=loc+" (49)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_ROLB:
                    resultado+=loc+" (59)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_RORA:
                    resultado+=loc+" (46)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_RORB:
                    resultado+=loc+" (56)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_RTI:
                    resultado+=loc+" (3B)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_RTS:
                    resultado+=loc+" (39)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_SBA:
                    resultado+=loc+" (10)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_SEC:
                    resultado+=loc+" (0D)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_SEI:
                    resultado+=loc+" (0F)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_SEV:
                    resultado+=loc+" (0B)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_STOP:
                    resultado+=loc+" (CF)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_SWI:
                    resultado+=loc+" (3F)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TAB:
                    resultado+=loc+" (16)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TAP:
                    resultado+=loc+" (06)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TBA:
                    resultado+=loc+" (17)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TETS:
                    resultado+=loc+" (00)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TPA:
                    resultado+=loc+" (07)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TSTA:
                    resultado+=loc+" (4D)\t\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TSTB:
                    resultado+=loc+" (5D)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TSX:
                    resultado+=loc+" (30)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TSY:
                    resultado+=loc+" (1830)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case INH_TXS:
                    resultado+=loc+" (35)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_TYS:
                    resultado+=loc+" (1835)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case INH_WAI:
                    resultado+=loc+" (3E)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_XGDX:
                    resultado+=loc+" (8F)\t \t: \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case INH_XGDY:
                    resultado+=loc+" (188F)\t\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                   
     // IMM *******************************************************************
                    
                case IMM_ADCA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (89"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_ADCA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado +=loc+ "  (89"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ADCA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (89"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ADCB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (C9"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_ADCB_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (C9"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ADCB_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado +=loc+ "  (C9"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ADDA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (8B"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_ADDA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (8B"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ADDA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (8B"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ADDB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (CB"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_ADDB_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (CB"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ADDB_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (CB"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ADDD_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (C3"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_ADDD_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (C3"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ADDD_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (C3"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ANDA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (84"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_ANDA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (84"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ANDA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (84"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ANDB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (C4"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                 case IMM_ANDB_DEC:
                     operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (C4"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                 case IMM_ANDB_CHAR:
                     operando=charIMM(lexer.lexeme);
                    resultado +=loc+ "  (C4"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_BITA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (85"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_BITA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (85"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_BITA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado +=loc+ "  (85"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_BITB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (C5"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_BITB_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado +=loc+ "  (C5"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_BITB_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (C5"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_CMPA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (81"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_CMPA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (81"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_CMPA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (81"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_CMPB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (C1"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_CMPB_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (C1"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_CMPB_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (C1"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_CPD_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (1A83"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case IMM_CPD_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (1A83"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,4);
                    break;
                case IMM_CPD_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (1A83"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,4);
                    break;
                case IMM_CPX_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (8C"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_CPX_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (8C"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_CPX_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (8C"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_CPY_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (188C"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case IMM_CPY_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado +=loc+ "  (188C"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,4);
                    break;
                case IMM_CPY_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (188C"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,4);
                    break;
                case IMM_EORA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (88"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_EORA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (88"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_EORA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (88"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_EORB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (C8"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_EORB_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (C8"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_EORB_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (C8"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDAA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (86"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_LDAA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (86"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDAA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (86"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDAB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (C6"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_LDAB_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (C6"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDAB_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (C6"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDD_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (CC"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_LDD_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (CC"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDD_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (CC"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDS_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (8E"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_LDS_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (8E"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDS_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (8E"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDX_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (CE"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_LDX_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado +=loc+ "  (CE"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDX_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (CE"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_LDY_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (18CE"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,4);
                    break;
                case IMM_LDY_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado +=loc+ "  (18CE"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,4);
                    break;
                case IMM_LDY_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (18CE"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,4);
                    break;
                case IMM_ORAA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (8A"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_ORAA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (8A"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ORAA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (8A"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ORAB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (CA"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_ORAB_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += "  (CA"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_ORAB_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (CA"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SBCA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (82"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_SBCA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (82"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SBCA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (82"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SBCB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (C2"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_SBCB_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (C2"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SBCB_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (C2"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SUBA_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (80"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_SUBA_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (80"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SUBA_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (80"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SUBB_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (C0"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_SUBB_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (C0"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SUBB_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (C0"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SUBD_HEXA:
                    operando=operandoH(lexer.lexeme);
                    opCode=opcode(lexer.lexeme,operando);
                    resultado+=loc+" (83"+operando.toUpperCase()+")\t : \t"+lexer.lexeme.toUpperCase();
                    loc=localidad(loc,2);
                    break;
                case IMM_SUBD_DEC:
                    operando=hexaIMM(lexer.lexeme);
                    resultado += loc+"  (83"+operando+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                case IMM_SUBD_CHAR:
                    operando=charIMM(lexer.lexeme);
                    resultado += loc+"  (83"+operando.toUpperCase()+")\t : \t" + lexer.lexeme;
                    loc=localidad(loc,2);
                    break;
                    
    // DIR*********************************************************************                
                case DIR_ADCA_DEC:
                    resultado += "  99\t" + lexer.lexeme + "\n";
                    break;
                case DIR_ADCA_HEXA:
                    
                    resultado += "  99\t" + lexer.lexeme + "\n";
                    break;
                    
//                case DIR_ADCB:
//                    resultado += "  D9\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_ADDA:
//                    resultado += "  9B\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_ADDB:
//                    resultado += "  DB\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_ADDD:
//                    resultado += "  D3\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_ANDA:
//                    resultado += "  94\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_ANDB:
//                    resultado += "  D4\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_BCLR:
//                    resultado += "  15\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_BITA:
//                    resultado += "  95\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_BITB:
//                    resultado += "  D5\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_BRCLR:
//                    resultado += "  13\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_BRSET:
//                    resultado += "  12\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_BSET:
//                    resultado += "  14\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_CMPA:
//                    resultado += "  91\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_CMPB:
//                    resultado += "  D1\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_CPD:
//                    resultado += "  1A 93\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_CPX:
//                    resultado += "  8C\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_CPY:
//                    resultado += "  18 9C\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_EORA:
//                    resultado += "  98\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_EORB:
//                    resultado += "  D8\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_JSR:
//                    resultado += "  9D\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_LDAA:
//                    resultado += "  96\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_LDAB:
//                    resultado += "  D6\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_LDD:
//                    resultado += "  DC\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_LDS:
//                    resultado += "  9E\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_LDX:
//                    resultado += "  DE\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_LDY:
//                    resultado += "  18 DE\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_ORAA:
//                    resultado += "  9A\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_ORAB:
//                    resultado += "  DA\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_SBCA:
//                    resultado += "  92\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_SBCB:
//                    resultado += "  D2\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_STAA:
//                    resultado += "  97\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_STAB:
//                    resultado += "  D7\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_STD:
//                    resultado += "  DD\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_STS:
//                    resultado += "  9F\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_STX:
//                    resultado += "  DF\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_STY:
//                    resultado += "  18 DF\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_SUBA:
//                    resultado += "  90\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_SUBB:
//                    resultado += "  D0\t" + lexer.lexeme + "\n";
//                    break;
//                case DIR_SUBD:
//                    resultado += "  93\t" + lexer.lexeme + "\n";
//                    break;
                case INDX_ADCA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (A9"+operando+")\t\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_ADCA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A9"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_ADCB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E9"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_ADCB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E9"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_ADDA:
                    operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (AB"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_ADDA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18AB"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_ADDB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (EB"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_ADDB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18EB"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_ADDD:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E3"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_ADDD:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E3"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_ANDA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (B4"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_ANDA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A4"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_ANDB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E4"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_ANDB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E4"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_ASL:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (68"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_ASL:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1868"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_ASR:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (67"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_ASR:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1867"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_BCLR:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        mascara=operandoH2(lexer.lexeme.substring(lexer.lexeme.indexOf(",")));
                        resultado+=loc+" (1D"+operando+mascara+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_BCLR:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        mascara=operandoH2(lexer.lexeme.substring(lexer.lexeme.indexOf(",")));
                        resultado+=loc+" (181D"+operando+mascara+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_BITA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (A5"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_BITA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A5"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_BITB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E5"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_BITB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E5"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;  
                case INDX_BRCLR:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        mascara=operandoH2(lexer.lexeme.substring(lexer.lexeme.indexOf(",")));
                        resultado+=loc+" (1F"+operando+mascara+"FC)\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_BRCLR:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        mascara=operandoH2(lexer.lexeme.substring(lexer.lexeme.indexOf(",")));
                        resultado+=loc+" (181F"+operando+mascara+"FC)\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_BRSET:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        mascara=operandoH2(lexer.lexeme.substring(lexer.lexeme.indexOf(",")));
                        resultado+=loc+" (1E"+operando+mascara+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_BRSET:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        mascara=operandoH2(lexer.lexeme.substring(lexer.lexeme.indexOf(",")));
                        resultado+=loc+" (181E"+operando+mascara+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_BSET:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        mascara=operandoH2(lexer.lexeme.substring(lexer.lexeme.indexOf(",")));
                        resultado+=loc+" (1C"+operando+mascara+"FC)\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_BSET:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        mascara=operandoH2(lexer.lexeme.substring(lexer.lexeme.indexOf(",")));
                        resultado+=loc+" (181C"+operando+mascara+"FC)\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_CLR:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (6F"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_CLR:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (186F"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_CMPA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (A1"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_CMPA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A1"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_CMPB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E1"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_CMPB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E1"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_COM:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (63"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_COM:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1863"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_CPD:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1AA3"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_CPX:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (AC"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_CPY:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1AAC"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_DEC:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (6A"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_EORA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (A8"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_EORB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E8"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_INC:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (6C"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_JMP:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (6E"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_JSR:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (AD"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_LDAA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (A6"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_LDAB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E6"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_LDD:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (EC"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_LDS:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (AE"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_LDX:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (EE"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_LDY:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1AEE"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_LSL:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (68"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_LSR:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (64"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_NEG:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (60"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_ORAA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (AA"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_ORAB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (EA"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_ROL:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (69"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_ROR:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (66"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_SBCA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (A2"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_SBCB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E2"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_STAA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (A7"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_STAB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E7"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_STD:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (ED"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_STS:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (AF"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_STX:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (EF"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_STY:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1AEF"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDX_SUBA:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (A0"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_SUBB:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (E0"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_SUBD:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (A3"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDX_TST:
                        operando=operandoH2(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (6D"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,2);
                        break;
                case INDY_CPD:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (CDA3"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_CPX:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (CDAC"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_CPY:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18AC"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_DEC:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (186A"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_EORA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A8"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_EORB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E8"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_INC:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (186C"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_JMP:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (186E"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_JSR:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18AD"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_LDAA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A6"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_LDAB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E6"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_LDD:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18EC"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_LDS:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18AE"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_LDX:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (CDEE"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_LDY:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18EE"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_LSL:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1868"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_LSR:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1864"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_NEG:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1860"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_ORAA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18AA"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_ORAB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18EA"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_ROL:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1869"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_ROR:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (1866"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_SBCA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A2"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_SBCB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E2"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_STAA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A7"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_STAB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E7"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_STD:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18ED"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_STS:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18AF"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_STX:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (CDEF"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_STY:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18EF"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_SUBA:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A0"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_SUBB:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18E0"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_SUBD:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (18A3"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case INDY_TST:
                        operando=operandoH4(lexer.lexeme);
                        opCode=opcode(lexer.lexeme,operando);
                        resultado+=loc+" (186D"+operando+")\t : \t"+lexer.lexeme.toUpperCase();
                        loc=localidad(loc,4);
                        break;
                case Numero:
                    resultado += " " + lexer.lexeme + "\n";
                    break;
                case ERROR:
                    resultado += "  <Simbolo no definido>\n";
                    break;
                default:
                    resultado += "  < " + lexer.lexeme + " >\n";
                    break;
                }
        }
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnArchivo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtResultado = new javax.swing.JTextArea();
        btnAnalizarLex = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAnalizarLex = new javax.swing.JTextArea();
        btnAnalizarSin = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtAnalizarSin = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnArchivo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnArchivo.setText("abrir archivo");
        btnArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArchivoActionPerformed(evt);
            }
        });

        txtResultado.setColumns(20);
        txtResultado.setRows(5);
        jScrollPane1.setViewportView(txtResultado);

        btnAnalizarLex.setText("analizar");
        btnAnalizarLex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnalizarLexActionPerformed(evt);
            }
        });

        jButton2.setText("jButton2");

        txtAnalizarLex.setEditable(false);
        txtAnalizarLex.setColumns(20);
        txtAnalizarLex.setRows(5);
        jScrollPane2.setViewportView(txtAnalizarLex);

        btnAnalizarSin.setText("analizar");
        btnAnalizarSin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnalizarSinActionPerformed(evt);
            }
        });

        jButton4.setText("jButton4");

        txtAnalizarSin.setColumns(20);
        txtAnalizarSin.setRows(5);
        jScrollPane3.setViewportView(txtAnalizarSin);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnArchivo, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 62, Short.MAX_VALUE)
                                .addComponent(btnAnalizarLex)
                                .addGap(302, 302, 302)
                                .addComponent(jButton2))
                            .addComponent(jScrollPane2)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAnalizarSin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnArchivo)
                    .addComponent(btnAnalizarLex)
                    .addComponent(jButton2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 315, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAnalizarSin)
                    .addComponent(jButton4))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchivoActionPerformed
//        File archivo=new File("archivo.txt");
//        PrintWriter escribir;
//        try {
//            escribir=new PrintWriter(archivo);
//            escribir.print(txtEntrada.getText());
//            escribir.close();
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
//        }
         
        JFileChooser chooser=new JFileChooser();
        chooser.showOpenDialog(null);
        File archivo=new File(chooser.getSelectedFile().getAbsolutePath());
        
        
        try {
            String ST=new String(Files.readAllBytes(archivo.toPath()));
            txtResultado.setText(ST);
                    
//                    
//            Reader lector=new BufferedReader(new FileReader(chooser.getSelectedFile()));
//            Lexer lexer=new Lexer(lector);
//            String resultado="";
//            while(true){
//                Tokens tokens=lexer.yylex();
//                if(tokens==null){
//                    resultado+="fin";
//                    txtResultado.setText(resultado);
//                    return;
//                }
//                switch (tokens) {
//                    case ERROR:
//                        resultado+="simbolo no definido\n";
//                        break;
//                    case Org:
//                        resultado+="ORG";
//                        break;
//                    case Equ:
//                        resultado+="EQU\n";
//                        break;
//                    case Fcb:
//                        resultado+="FCB\n";
//                        break;
//                    case End:
//                        resultado+="END\n";
//                        break;
//                    case Comentario:
//                        resultado+="comentario : "+lexer.lexeme+"\n";
//                        break;
//                    case Etiq_Var_Instrucc:
//                        resultado+="etiqueta, variable o instruccion: "+lexer.lexeme+"\n";
//                        break;
//                    case NumeroHexaIMM:
//                        resultado+="Operando hexa imm: "+lexer.lexeme+"\n";
//                        break;
//                    case NumeroDecIMM:
//                        resultado+="Operando deci imm: "+lexer.lexeme+"\n";
//                        break;
//                    case CharIMM:
//                        resultado+="caracter imm: "+lexer.lexeme+"\n";
//                        break;
//                    case NumeroHexaDIR:
//                        resultado+="Operando hexa dir: "+lexer.lexeme+"\n";
//                        break;
//                    case NumeroDecDIR_EXT:
//                        resultado+="Operando deci dir o ext: "+lexer.lexeme+"\n";
//                        break;
//                    case NumeroHexaEXT:
//                        resultado+="Operando hexa ext: "+lexer.lexeme+"\n";
//                        break;
//                    case NumeroHexaINDX:
//                        resultado+="Operando hexa indx: "+lexer.lexeme+"\n";
//                        break;
//                    case NumeroHexaINDY:
//                        resultado+="Operando hexa indy: "+lexer.lexeme+"\n";
//                        break;
//                    case Espacio:
//                        resultado+=" espacio ";
//                        break;
//                    case Org_Equ:
//                        resultado+=" directiva "+lexer.lexeme+"\n";
//                        break;
//                    default:
//                        resultado+="Token: "+tokens+"\n";
//                        break;
//                }
//            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnArchivoActionPerformed

    public String operandoH2(String lexer){
//        System.out.println(lexer);
        int i=lexer.indexOf("$");
        String operando=lexer.substring(i+1,i+3);
        return operando;
    }
    public String operandoH4(String lexer){
        int i=lexer.indexOf("$");
        String operando=lexer.substring(i+1,i+5);
        
        return operando;
    }
    
    public String operandoH(String lexer){
        int i=lexer.indexOf("$");
        String operando=lexer.substring(i+1);
        
        return operando;
    }
    
    public String hexaIMM(String lexer){
        int i=lexer.indexOf("#");
        String operando=lexer.substring(i+1);
        operando=Integer.toHexString(Integer.parseInt(operando));
        return operando;
    }
    
    public String charIMM(String lexer){
        int i=lexer.indexOf("#");
        String operando=lexer.substring(i+2);
        char car=operando.charAt(0);
        operando=Integer.toHexString((int)car);
        return operando;
    }
    
    public String opcode(String lexer,String operando){
        String opCode=lexer.stripLeading();
        int i=opCode.indexOf(operando.charAt((0)));
        opCode=opCode.substring(0,i);
        opCode=opCode.stripTrailing();
        return opCode;
    }
    
    public String localidad(String loc,int a){
        int i=Integer.parseInt(loc,16);
        i=i+a;
        loc=Integer.toHexString(i);
        return loc.toUpperCase();
    }
    
    private void btnAnalizarLexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnalizarLexActionPerformed
        try {
           
            analizarLexico();
        } catch (IOException ex) {
            Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnAnalizarLexActionPerformed

    private void btnAnalizarSinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnalizarSinActionPerformed
        String ST=txtResultado.getText();
        Sintax s=new Sintax(new codigo.LexerCup(new StringReader(ST)));
        
        try {
            s.parse();
            txtAnalizarSin.setText("analisis correcto");
            txtAnalizarSin.setForeground(new Color(25,111,61));
        } catch (Exception ex) {
            Symbol sym=s.getS();
            txtAnalizarSin.setText("ERROR de sintaxis. Linea "+(sym.right+1)+" columna: "+(sym.left+1)+", texto \">"+sym.value+"<\"");
            txtAnalizarSin.setForeground(Color.red);
        }
        
        
    }//GEN-LAST:event_btnAnalizarSinActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnalizarLex;
    private javax.swing.JButton btnAnalizarSin;
    private javax.swing.JButton btnArchivo;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea txtAnalizarLex;
    private javax.swing.JTextArea txtAnalizarSin;
    private javax.swing.JTextArea txtResultado;
    // End of variables declaration//GEN-END:variables
}
