/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package codigo;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import java_cup.runtime.Symbol;
import javax.swing.JFileChooser;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author miran
 */
public class FrmPrincipal extends javax.swing.JFrame {

    File archivo;
    String txtResultado;
    String loc;
//    Hashtable<String,String> Subrut;
    
    public FrmPrincipal() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    
    private Hashtable<String,String> subrut(Reader lector) throws IOException {
        int cont=1;
        Lexer lexer =new Lexer(lector);
       
        Hashtable<String,String> Equ=new Hashtable();
        Hashtable<String,String> Subrut=new Hashtable<String,String>();
//        Hashtable<String,Integer> pendiente=new Hashtable<String,Integer>();
        Util util=new Util();

        
        String[] tok=new String[15];
        String tmp="";
        this.loc="8000";
        
        
        int i=0,k;
        
        String linea="";

        String mnem,operando,var,sub;
        Instr tmpI;


        String sintax;
        
        String[] code;
        Util u=new Util();
        
        while(true){
            Tokens token=lexer.yylex();
            if(token==null){
                
                
                return Subrut;
            }
           
            switch (token) {
                case Linea:
                        tok[i]="LINEA";
                        
                        Hashtable EquT=new Hashtable();
                    
                        linea=linea.stripTrailing();
                    
                        sintax=Sintaxis(tok);
                        
                        
                        if(sintax!="LINEA"&sintax!="ESPACIO"){
                            code=CodigoF(tmp);
                            k=code.length;

                            switch(sintax){
                            case "COMENTARIO":
                                break;

                 // IMM************************************************
                           
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM": 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;
                                
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM_ESPACIO_COMENTARIO":
                                sub=code[0];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;
                                
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM_ESPACIO_COMENTARIO":
                                sub=code[0];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM_ESPACIO_COMENTARIO":
                                sub=code[0];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                  
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM_ESPACIO_COMENTARIO":
                                sub=code[0];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;

                    // DIR**********************************************************************

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR_ESPACIO_COMENTARIO":
                                sub=code[0];
                                Subrut.put(sub,loc);
                                mnem=code[2];
                                loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR_ESPACIO_COMENTARIO":
                                sub=code[0];
                                Subrut.put(sub,loc);
                                mnem=code[2];
                                loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                sub=code[0];
                                Subrut.put(sub,loc);
                                mnem=code[2];
                                loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_OMENTARIO":
                                
                                sub=code[0];
                                Subrut.put(sub,loc);
                                mnem=code[2];
                                loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT_ESPACIO_COMENTARIO":
                                
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT_ESPACIO_COMENTARIO":
                                sub=code[0];
                                Subrut.put(sub,loc);
                                break;

                     // EXT *******************************************************************


                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT_ESPACIO_COMENTARIO":
                                sub=code[0];
                                Subrut.put(sub,loc);
                                mnem=code[2];
                                loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT_ESPACIO_COMENTARIO":
                                sub=code[0];
                                Subrut.put(sub,loc);
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                break;

                //INDX ***********************************************************
                                
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX_ESPACIO_COMENTARIO":
                                sub=code[0];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY_ESPACIO_COMENTARIO":
                                sub=code[0];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                sub=code[0];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                sub=code[0];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_COMENTARIO":
                                sub=code[0];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;

                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_COMENTARIO":
                                sub=code[0];
                                Subrut.put(sub,loc);
                                mnem=code[2];
                                loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;

                       // EXT ETIQUETA
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                                sub=code[0]; 
//                                Subrut.put(sub,loc);
                                var=code[3];
                                mnem=code[1];
                                if(Equ.get(var)!=null){
                                    if((util.buscarOpEXT(mnem)!=null)&&(Integer.parseInt((String)Equ.get(var),16)>255)){
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                    }else if((util.buscarOpDIR(mnem)!=null)&&(Integer.parseInt((String)Equ.get(var),16)<256)){
                                        this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                    }else if(util.buscarOpEXT(mnem)!=null){
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                    }
                                }else {
                                    if(util.buscarOpEXT(mnem)!=null){
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                    }else if(util.buscarOpREL(mnem)!=null){
                                        this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());
                                    }
                                }
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                sub=code[0];
                                var=code[4];
                                mnem=code[2];
                                Subrut.put(sub,loc);
                                if(Equ.get(var)!=null){
                                    if((util.buscarOpDIR(mnem)!=null)){
                                        this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                    }else if((util.buscarOpEXT(mnem)!=null)){
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                    }
                                }else {
                                    if(util.buscarOpEXT(mnem)!=null){
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                    }else if(util.buscarOpREL(mnem)!=null){
                                        this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());
                                    }
                                }
                                break;

                   // INH
                            case "ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpINH(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                sub=code[0];
                                Subrut.put(sub,loc);
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpINH(mnem).getBy());
                                break;

                    // EQU ETIQUETAS **********************************************************

                            case "ET.VAR.MNEM.SUB_ESPACIO_EQU_ESPACIO_H.ORG.EQU.EXT":
                                
                                Equ.put(code[0], code[4].substring(1));
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_EQU_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
                                break;

                    // ORG *******************************************************************
                            case "ESPACIO_ORG_ESPACIO_H.ORG.EQU.EXT":
                            case "ESPACIO_ORG_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
                                this.loc=code[3].substring(1);
                                break;

                    // subrut ****************************************************************
                            case "ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                sub=code[0];
                                Subrut.put(sub,loc);
//                                System.out.println(sub+">"+Subrut.get(sub));
                                break;

                            case "ESPACIO_FCB_ESPACIO_H.FCB":
                            case "ESPACIO_FCB_ESPACIO_H.FCB_ESPACIO_COMENTARIO":
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_FCB_ESPACIO_H.FCB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_FCB_ESPACIO_H.FCB_ESPACIO_COMENTARIO":
                                
                                break;

                            case "ESPACIO_END_ESPACIO_H.ORG.EQU.EXT":
                                break;

                            default:
                                System.out.println(">"+sintax+"<");
                                System.out.print(">>");

                                for(int j=0;j<i;j++){
                                    System.out.print(code[j]);
                                }
                                System.out.print("<<\n");
                                break;

                        }
                            for(int j=0;j<k;j++){
                               
                            }
                            
                        }else {

                            

                        }
                        
                        tmp="";
                        
                        i=0;
                        cont++;
                        break;
                case ERROR:
                        break;
                case Org:
                        tok[i]="ORG";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Equ:
                        tok[i]="EQU";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Fcb:
                        tok[i]="FCB";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case End:
                        tok[i]="END";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Comentario:
                        tok[i]="COMENTARIO";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Etiq_Var_Instrucc:
                        tok[i]="ET.VAR.MNEM.SUB";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case EtiqIMM:
                        tok[i]="ET.IMM";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                 
                case NumeroHexaIMM:
                        tok[i]="H.IMM";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDecIMM:
                        tok[i]="D.IMM";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case CharIMM:
                        tok[i]="C.IMM";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroHexaDIR:
                        tok[i]="H.DIR";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDecDIR:
                        tok[i]="D.DIR";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDecEXT:
                        tok[i]="D.EXT";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDecEXT_DIR:
                        tok[i]="D.DIR.EXT";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroHexaEXT:
                        tok[i]="H.EXT";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroHexaINDX:
                        tok[i]="H.INDX";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroHexaINDY:
                        tok[i]="H.INDY";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Espacio:
                        tok[i]="ESPACIO";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case HexaExtOrgEqu:
                        tok[i]="H.ORG.EQU.EXT";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDIR:
                        tok[i]="N.DIR";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroINDX:
                        tok[i]="N.INDX";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroINDY:
                        tok[i]="N.INDY";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                        
                case NumFCB:
                        tok[i]="H.FCB";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                        
                default:
                        System.out.println("SIMBOLO NO ENCONTRADO: "+lexer.lexeme);
                        break;
                
                }
            
        }
    }
    
    private void analizarLexico(Reader lector,Hashtable<String,String> Subr) throws IOException{
        int cont=1;
        Lexer lexer =new Lexer(lector);
       
        Hashtable Equ=new Hashtable();
//        Hashtable<String,String> Subrut=new Hashtable<String,String>();
        Hashtable<String,Integer> pendiente=new Hashtable<String,Integer>();
        Util util=new Util();
        int rel;
//        System.out.println(Subr);
        String[] tok=new String[15];
        String tmp="";
        this.loc="8000";
        String loc2;
        FileWriter lst=new FileWriter("./"+this.archivo.getName().substring(0,
                this.archivo.getName().lastIndexOf("."))+".LST");
        FileWriter s19=new FileWriter("./"+this.archivo.getName().substring(0,
                this.archivo.getName().lastIndexOf("."))+".S19");
        
        int i=0,k,end=0;
        
        String linea="";

        String mnem,operando,var,sub,bin;
        Instr tmpI;

        String sintax;
        
        String[] code;
        Util u=new Util();
        
        while(true){
            Tokens token=lexer.yylex();
            if(token==null){
                if(end==0){
                    lst.write("** ERROR 010\t\t:\t");
                }
                
                txtAnalizarLex.setText("Archivos generados:\n > "+
                        this.archivo.getName().substring(0,
                        this.archivo.getName().lastIndexOf("."))+".LST"+
                        "\n > "+
                        this.archivo.getName().substring(0,
                        this.archivo.getName().lastIndexOf("."))+".S19");
                lst.close();
                s19.close();
                return;
            }
           
            switch (token) {
                case Linea:
                        tok[i]="LINEA";
                        
//                        Equ=Lineas(tmp,tok,lst,s19,cont,Equ,util);
                        Hashtable EquT=new Hashtable();
                    
                           linea=linea.stripTrailing();
                    
                          sintax=Sintaxis(tok);
                        
                        
                          if(sintax!="LINEA"&sintax!="ESPACIO"){
                          code=CodigoF(tmp);
                            k=code.length;

                            switch(sintax){
                            case "COMENTARIO":
                                lst.write(cont+":\t\t\t:\t");
                                break;
                              
                 // IMM************************************************
//                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
                             case "ET.VAR.MNEM.SUB_ESPACIO_H.IMM":
                             case "ET.VAR.MNEM.SUB_ESPACIO_H.IMM_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM": 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                var=code[3].substring(2);
                                lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp());
                                if(util.buscarOpIMM(mnem).getOpBy()>1){
                                    for(int m=var.length();m<4;m++)
                                        lst.write("0");
                                    lst.write(var+")\t:\t");
                                    
                                }else{
                                    lst.write(var+")    \t:\t");
                                
                                }
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                var=code[4].substring(2);
                                lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp());
                                if(util.buscarOpIMM(mnem).getOpBy()>1){
                                    for(int m=var.length();m<4;m++)
                                        lst.write("0");
                                    lst.write(var+")\t:\t");
                                    
                                }else{
                                    lst.write(var+")    \t:\t");
                                
                                }
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;
                                
                            case "ET.VAR.MNEM.SUB_ESPACIO_D.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_D.IMM_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
                                        DecAHexaIMM(code[3],util.buscarOpIMM(mnem).getOpBy())+
                                        ")\t:\t");
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
                                        DecAHexaIMM(code[4],util.buscarOpIMM(mnem).getOpBy())+
                                        ")\t:\t");
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;
                                
                            case "ET.VAR.MNEM.SUB_ESPACIO_C.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_C.IMM_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
                                        CharAHexaIMM(code[3])+")\t:\t");
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
                                        CharAHexaIMM(code[4])+")\t:\t");
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;
                            
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.IMM_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                sub=code[3].substring(1);
                                if(util.buscarOpIMM(mnem)!=null){
                                    if(Equ.get(sub)!=null){
                                        lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
                                                Equ.get(sub)+")\t:\t");
                                        loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                    }else{
                                    }
                                }else{
                                    
                                }
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                sub=code[4].substring(1);
                                if(util.buscarOpIMM(mnem)!=null){
                                    if(Equ.get(sub)!=null){
                                        lst.write(cont+": "+loc+" ("+util.buscarOpIMM(mnem).getOp()+
                                                Equ.get(sub)+")\t:\t");
                                        loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                    }else{
                                    }
                                }else{
                                    
                                }
                                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
                                break;

                    // DIR**********************************************************************
                             case "ET.VAR.MNEM.SUB_ESPACIO_H.DIR":
                             case "ET.VAR.MNEM.SUB_ESPACIO_H.DIR_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                                
                                case "ET.VAR.MNEM.SUB_ESPACIO_D.DIR":
                             case "ET.VAR.MNEM.SUB_ESPACIO_D.DIR_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                                
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.DIR":
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;    
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_OMENTARIO":
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                break;
                            
                            case "ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT":
                            case "ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT_ESPACIO_COMENTARIO":
                                
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT_ESPACIO_COMENTARIO":
                                break;

                     // EXT *******************************************************************

                            case "ET.VAR.MNEM.SUB_ESPACIO_H.EXT":
                            case "ET.VAR.MNEM.SUB_ESPACIO_H.EXT_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break; 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                break;
                                
                                case "ET.VAR.MNEM.SUB_ESPACIO_D.EXT":
                            case "ET.VAR.MNEM.SUB_ESPACIO_D.EXT_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break; 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                break;
                                
         // INDX Y *************************************************************
                            case "ET.VAR.MNEM.SUB_ESPACIO_H.INDX":
                            case "ET.VAR.MNEM.SUB_ESPACIO_H.INDX_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break; 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;
                                
                                case "ET.VAR.MNEM.SUB_ESPACIO_H.INDY":
                            case "ET.VAR.MNEM.SUB_ESPACIO_H.INDY_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break; 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                var=code[3].substring(1,3);
                                lst.write(cont+": "+loc+" ("+util.buscarOpINDY(mnem).getOp()+
                                        var+")\t:\t");
                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                var=code[4].substring(1,3);
                                lst.write(cont+": "+loc+" ("+util.buscarOpINDY(mnem).getOp()+
                                        var+")\t:\t");
                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;
                                
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break; 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                var=code[3].substring(8);
                                sub=code[5];
                                
                                if(Subr.get(sub)!=null){
                                    if(util.buscarOpINDX(mnem)!=null){
                                        loc2=loc;
                                        if(Integer.parseInt(Subr.get(sub),16)<Integer.parseInt(localidad(loc2,
                                                util.buscarOpINDX(mnem).getOpBy()),16)){
                                            rel=Integer.parseInt( localidad(loc2,util.buscarOpINDX(mnem).getOpBy()),16) - 
                                                    Integer.parseInt(Subr.get(sub),16) +1;

                                            bin=Integer.toBinaryString(rel);
                                            bin=complemento2(bin);
                                            lst.write(cont+": "+loc+" ("+util.buscarOpINDX(mnem).getOp()+
                                                "00"+var+bin.toUpperCase()+")\t:\t");
                                            this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                        }else{
//                                            rel=Integer.parseInt(Subr.get(var),16)- Integer.parseInt(localidad(loc2,2),16);
//                                            bin=Integer.toHexString(rel);
//                                            lst.write(cont+": "+loc+" ("+util.buscarOpREL(mnem).getOp());
//                                            if(bin.toUpperCase().length()<2){
//                                                lst.write("0");
//                                            }
//                                                lst.write(bin.toUpperCase()+")\t:\t");
//                                             this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());  
                                        }
                                    }
                                }
//                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                var=code[4].substring(8);
                                sub=code[6];
                                
                                if(Subr.get(sub)!=null){
                                    if(util.buscarOpINDX(mnem)!=null){
                                        loc2=loc;
                                        if(Integer.parseInt(Subr.get(sub),16)<Integer.parseInt(localidad(loc2,
                                                util.buscarOpINDX(mnem).getOpBy()),16)){
                                            rel=Integer.parseInt( localidad(loc2,util.buscarOpINDX(mnem).getOpBy()),16) -
                                                    Integer.parseInt(Subr.get(sub),16) +1;

                                            bin=Integer.toBinaryString(rel);
                                            bin=complemento2(bin);
                                            lst.write(cont+": "+loc+" ("+util.buscarOpINDX(mnem).getOp()+
                                                "00"+var+bin.toUpperCase()+")\t:\t");
                                            this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                        }else{
//                                            rel=Integer.parseInt(Subr.get(var),16)- Integer.parseInt(localidad(loc2,2),16);
//                                            bin=Integer.toHexString(rel);
//                                            lst.write(cont+": "+loc+" ("+util.buscarOpREL(mnem).getOp());
//                                            if(bin.toUpperCase().length()<2){
//                                                lst.write("0");
//                                            }
//                                                lst.write(bin.toUpperCase()+")\t:\t");
//                                             this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());  
                                        }
                                    }
                                }
                                break;
                            
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break; 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;
                                
                                case "ET.VAR.MNEM.SUB_ESPACIO_N.INDX":
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break; 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                operando=code[3].substring(8);
                                lst.write(cont+": "+loc+" ("+util.buscarOpINDX(mnem).getOp()+
                                        "00"+operando+")\t:\t");
                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                operando=code[4].substring(8);
                                lst.write(cont+": "+loc+" ("+util.buscarOpINDX(mnem).getOp()+
                                        "00"+operando+")\t:\t");
                                this.loc=localidad(loc,util.buscarOpINDX(mnem).getBy());
                                break;
                                
                                case "ET.VAR.MNEM.SUB_ESPACIO_N.INDY":
                            case "ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break; 
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_COMENTARIO":
                                mnem=code[1];
                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                this.loc=localidad(loc,util.buscarOpINDY(mnem).getBy());
                                break;

                       // EXT ETIQUETA
                               
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                var=code[3];
                                mnem=code[1];
                                loc2=loc;
                                if(Equ.get(var)!=null){
                                    if((util.buscarOpEXT(mnem)!=null)&&(Integer.parseInt((String)Equ.get(var),16)>255)){
                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
                                        Equ.get(var)+")\t:\t");
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());

                                    }else if((util.buscarOpDIR(mnem)!=null)&&(Integer.parseInt((String)Equ.get(var),16)<256)){
                                        operando=(String)Equ.get(var);
                                        lst.write(cont+": "+loc+" ("+util.buscarOpDIR(mnem).getOp()+
                                        operando.substring(2)+")\t:\t");
                                        this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                    }else if(util.buscarOpEXT(mnem)!=null){
                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
                                        Equ.get(var)+")\t:\t");
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                    }
                                }else if(Subr.get(var)!=null){
                                    if(util.buscarOpEXT(mnem)!=null){
                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
                                                Subr.get(var)+")\t:\t");
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                    }else if(util.buscarOpREL(mnem)!=null){
                                        if(Integer.parseInt(Subr.get(var),16)<Integer.parseInt(loc2,16)){
                                            rel=Integer.parseInt( localidad(loc2,1),16) - Integer.parseInt(Subr.get(var),16) +1;
//                                          
                                            bin=Integer.toBinaryString(rel);
//                                            System.out.println("bin:"+bin);
                                            
                                            bin=complemento2(bin);
//                                            System.out.println("bin:"+bin);
                                            lst.write(cont+": "+loc+" ("+util.buscarOpREL(mnem).getOp()+
                                                bin.toUpperCase()+")\t:\t");
                                            this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());
                                        }else{
                                            rel=Integer.parseInt(Subr.get(var),16)- Integer.parseInt(localidad(loc2,2),16);
                                            bin=Integer.toHexString(rel);
                                            lst.write(cont+": "+loc+" ("+util.buscarOpREL(mnem).getOp());
                                            if(bin.toUpperCase().length()<2){
                                                lst.write("0");
                                            }
                                            lst.write(bin.toUpperCase()+")\t:\t");
                                            this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());   
                                        }
                                    }
                                }
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                var=code[4];
                                mnem=code[2];
                                loc2=loc;
                                if(Equ.get(var)!=null){
                                    if((util.buscarOpEXT(mnem)!=null)&&(Integer.parseInt((String)Equ.get(var),16)>255)){
                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
                                        Equ.get(var)+")\t:\t");
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());

                                    }else if((util.buscarOpDIR(mnem)!=null)&&(Integer.parseInt((String)Equ.get(var),16)<256)){
                                        operando=(String)Equ.get(var);
                                        lst.write(cont+": "+loc+" ("+util.buscarOpDIR(mnem).getOp()+
                                        operando.substring(2)+")\t:\t");
                                        this.loc=localidad(loc,util.buscarOpDIR(mnem).getBy());
                                    }else if(util.buscarOpEXT(mnem)!=null){
                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
                                        Equ.get(var)+")\t:\t");
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                    }
                                }else if(Subr.get(var)!=null){
                                    if(util.buscarOpEXT(mnem)!=null){
                                        lst.write(cont+": "+loc+" ("+util.buscarOpEXT(mnem).getOp()+
                                                Subr.get(var)+")\t:\t");
                                        this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
                                    }else if(util.buscarOpREL(mnem)!=null){
                                        if(Integer.parseInt(Subr.get(var),16)<Integer.parseInt(loc2,16)){
                                            rel=Integer.parseInt( localidad(loc2,1),16) - Integer.parseInt(Subr.get(var),16) +1;
//                                          
                                            bin=Integer.toBinaryString(rel);
                                            bin=complemento2(bin);
                                            lst.write(cont+": "+loc+" ("+util.buscarOpREL(mnem).getOp()+
                                                bin.toUpperCase()+")\t:\t");
                                            this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());
                                        }else{
                                            rel=Integer.parseInt(Subr.get(var),16)- Integer.parseInt(localidad(loc2,2),16);
                                            bin=Integer.toHexString(rel);
                                            lst.write(cont+": "+loc+" ("+util.buscarOpREL(mnem).getOp());
                                            if(bin.toUpperCase().length()<2){
                                                lst.write("0");
                                            }
                                            lst.write(bin.toUpperCase()+")\t:\t");
                                            this.loc=localidad(loc,util.buscarOpREL(mnem).getBy());   
                                        }
                                    }
                                }
                                break;

                   // INH****************************************************
                            
                            case "ESPACIO_ET.VAR.MNEM.SUB":
                            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[1];
                               // System.out.println(mnem);
                                lst.write(cont+": "+loc+" ("+util.buscarOpINH(mnem).getOp()+")");
                                if(util.buscarOpINH(mnem).getOp().length()<3){
                                    lst.write("\t");
                                }
                                lst.write("\t:\t");
                                this.loc=localidad(loc,util.buscarOpINH(mnem).getBy());
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                mnem=code[2];
                                lst.write(cont+": "+loc+" ("+util.buscarOpINH(mnem).getOp()+")");
                                if(util.buscarOpINH(mnem).getOp().length()<3){
                                    lst.write("\t");
                                }
                                lst.write("\t:\t");
                                this.loc=localidad(loc,util.buscarOpINH(mnem).getBy());
                                break;

                    // EQU ETIQUETAS **********************************************************

                            case "ET.VAR.MNEM.SUB_ESPACIO_EQU_ESPACIO_H.ORG.EQU.EXT":
                                lst.write(cont+": \t"+code[4].substring(1)+"\t\t:\t");
                                Equ.put(code[0], code[4].substring(1));
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_EQU_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
                                lst.write(cont+": \t"+code[4].substring(1)+"\t\t:\t");
                                Equ.put(code[0], code[4].substring(1));
                                break;

                    // ORG *******************************************************************
                            case "ESPACIO_ORG_ESPACIO_H.ORG.EQU.EXT":
                            case "ESPACIO_ORG_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
                                lst.write(cont+": \t ("+code[3].substring(1)+")\t\t:\t");
                                this.loc=code[3].substring(1);
                                break;

                    // SUBRUTINAS **********************************************
                            case "ET.VAR.MNEM.SUB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
                                lst.write(cont+": "+loc+"\t\t:\t");
                                break;
                            
                            case "ESPACIO_FCB_ESPACIO_H.FCB":
                            case "ESPACIO_FCB_ESPACIO_H.FCB_ESPACIO_COMENTARIO":
                                lst.write(cont+": "+loc+" ("+code[3].substring(1,3)+
                                        code[3].substring(5)+")\t:\t");
                                break;
                            case "ET.VAR.MNEM.SUB_ESPACIO_FCB_ESPACIO_H.FCB":
                            case "ET.VAR.MNEM.SUB_ESPACIO_FCB_ESPACIO_H.FCB_ESPACIO_COMENTARIO":
                                lst.write(cont+": "+loc+" ("+code[4].substring(1,3)+
                                        code[4].substring(5)+")\t:\t");
                                break;
                    // END *************************************************       
                            case "END_ESPACIO_H.ORG.EQU.EXT":
                            case "END_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
                                lst.write("** ERROR 009\t\t:\t");
                                break;
                            case "ESPACIO_END_ESPACIO_H.ORG.EQU.EXT":
                            case "ESPACIO_END_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
                                end++;
                                lst.write(cont+":\t\t\t:\t");
                                break;
                                
                    // ERRORES *******************************************
                                
                            case "ORG_ESPACIO_H.ORG.EQU.EXT":
                                lst.write("** ERROR 009");

                            default:
                                System.out.println(">"+sintax+"<");
                                System.out.print(">>");

                                for(int j=0;j<i;j++){
                                    System.out.print(code[j]);
                                }
                                System.out.print("<<\n");
                                break;

                        }
                            for(int j=0;j<k;j++){
                                lst.write(code[j]);
                            }
                            lst.write("\n");
                        }else {

                            lst.write(cont+":\n");

                        }
                        
                        tmp="";
                        
                        i=0;
                        cont++;
                        break;
                case ERROR:
                        break;
                case Org:
                        tok[i]="ORG";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Equ:
                        tok[i]="EQU";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Fcb:
                        tok[i]="FCB";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case End:
                        tok[i]="END";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Comentario:
                        tok[i]="COMENTARIO";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Etiq_Var_Instrucc:
                        tok[i]="ET.VAR.MNEM.SUB";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case EtiqIMM:
                        tok[i]="ET.IMM";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                 
                case NumeroHexaIMM:
                        tok[i]="H.IMM";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDecIMM:
                        tok[i]="D.IMM";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case CharIMM:
                        tok[i]="C.IMM";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroHexaDIR:
                        tok[i]="H.DIR";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDecDIR:
                        tok[i]="D.DIR";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDecEXT:
                        tok[i]="D.EXT";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDecEXT_DIR:
                        tok[i]="D.DIR.EXT";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroHexaEXT:
                        tok[i]="H.EXT";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroHexaINDX:
                        tok[i]="H.INDX";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroHexaINDY:
                        tok[i]="H.INDY";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case Espacio:
                        tok[i]="ESPACIO";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case HexaExtOrgEqu:
                        tok[i]="H.ORG.EQU.EXT";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroDIR:
                        tok[i]="N.DIR";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroINDX:
                        tok[i]="N.INDX";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                case NumeroINDY:
                        tok[i]="N.INDY";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                        
                case NumFCB:
                        tok[i]="H.FCB";
                        tmp+="@"+lexer.lexeme.toString();
                        i++;
                        break;
                        
                default:
                        System.out.println("SIMBOLO NO ENCONTRADO: "+lexer.lexeme);
                        break;
                
                }
            
        }
    }
    
    public String complemento2(String bin){
        while(bin.length()<8){
            bin="0"+bin;
        }
//        System.out.println(">"+bin);
        
        bin=bin.replace('1', '2');
        bin=bin.replace('0', '1');
        bin=bin.replace('2','0');
//        System.out.println(">"+bin);

        bin=Integer.toHexString(Integer.parseInt(bin,2)+1);
//        System.out.println(">"+bin);

        
        return bin;
    }
//    
//    public Hashtable Lineas(String linea,String[] token,FileWriter lst,FileWriter s19,
//          int cont, Hashtable Equ,Util util) throws IOException{
////        Hashtable EquT=new Hashtable();
////        EquT=Equ;
//        linea=linea.stripTrailing();
//        String mnem,operando,var;
//        Instr tmpI;
//        Hashtable<String,String> tmp=new Hashtable<String,String>();
////        Util u=new Util();
//        
//
//        String sintax=Sintaxis(token);
//        if(sintax!="LINEA"&sintax!="ESPACIO"){
//            String[] code=CodigoF(linea);
//            int i=code.length;
//
//            switch(sintax){
//            case "COMENTARIO":
//                lst.write(cont+":\t\t\t:\t");
//                break;
//                
// // IMM************************************************
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM": 
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM_ESPACIO_COMENTARIO":
//                mnem=code[1];
//                lst.write(cont+":"+loc+" ("+util.buscarOpIMM(mnem).getOp()+
//                        code[3].substring(2)+")\t");
//                if(code[3].substring(2).length()<4)
//                    lst.write("\t");
//                lst.write(":\t");
//                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.IMM_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM_ESPACIO_COMENTARIO":
//                mnem=code[1];
//                lst.write(cont+":"+loc+" ("+util.buscarOpIMM(mnem).getOp()+
//                        DecAHexaIMM(code[3],util.buscarOpIMM(mnem).getOpBy())+
//                        ")\t:\t");
//                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.IMM_ESPACIO_COMENTARIO":
//                
//                break;
//           
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM_ESPACIO_COMENTARIO":
//                mnem=code[1];
//                lst.write(cont+":"+loc+" ("+util.buscarOpIMM(mnem).getOp()+
//                        CharAHexaIMM(code[3])+")\t\t:\t");
//                this.loc=localidad(loc,util.buscarOpIMM(mnem).getBy());
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_C.IMM_ESPACIO_COMENTARIO":
//                break;
//                
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.IMM_ESPACIO_COMENTARIO":
//                break;
//            
//    // DIR**********************************************************************
//                
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.DIR_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.DIR_ESPACIO_OMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.DIR.EXT_ESPACIO_COMENTARIO":
//                break;
//            
//     // EXT *******************************************************************
//            
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.EXT_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_D.EXT_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDX_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_H.INDY_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                break;
//                
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDX_ESPACIO_COMENTARIO":
//                break;
//            
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_N.INDY_ESPACIO_COMENTARIO":
//                break;
//            
//       // EXT ETIQUETA
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                var=code[3];
//                mnem=code[1];
//                if(Equ.get(var)!=null){
//                    if(util.buscarOpEXT(mnem).getOp()!=null&&Integer.parseInt((String)Equ.get(var),16)>255){
//
//                    lst.write(cont+":"+loc+" ("+util.buscarOpEXT(mnem).getOp()+
//                            Equ.get(var)+")\t:\t");
//                    this.loc=localidad(loc,util.buscarOpEXT(mnem).getBy());
//                    }else{
////                        System.out.println("sad");
//                    }
//                }
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                break;
//                
//   // INH
//            case "ESPACIO_ET.VAR.MNEM.SUB":
//            case "ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                mnem=code[1];
//               // System.out.println(mnem);
//                lst.write(cont+":"+loc+" ("+util.buscarOpINH(mnem).getOp()+")\t\t:\t");
//                this.loc=localidad(loc,util.buscarOpINH(mnem).getBy());
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB":
//            case "ET.VAR.MNEM.SUB_ESPACIO_ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                break;
//                
//    // EQU ETIQUETAS **********************************************************
//                
//            case "ET.VAR.MNEM.SUB_ESPACIO_EQU_ESPACIO_H.ORG.EQU.EXT":
//                lst.write(cont+":\t"+code[4].substring(1)+"\t\t:\t");
//                Equ.put(code[0], code[4].substring(1));
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_EQU_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
//                break;
//                
//    // ORG *******************************************************************
//            case "ESPACIO_ORG_ESPACIO_H.ORG.EQU.EXT":
//            case "ESPACIO_ORG_ESPACIO_H.ORG.EQU.EXT_ESPACIO_COMENTARIO":
//                lst.write(cont+":\t("+code[3].substring(1)+")\t\t:\t");
//                break;
//                
//    // subrut ****************************************************************
//            case "ET.VAR.MNEM.SUB":
//            case "ET.VAR.MNEM.SUB_ESPACIO_COMENTARIO":
//                tmp.put(code[0],loc);
//                lst.write(cont+": "+loc+"\t\t:\t");
//                break;
//                
//            case "ESPACIO_FCB_ESPACIO_H.FCB":
//            case "ESPACIO_FCB_ESPACIO_H.FCB_ESPACIO_COMENTARIO":
//                break;
//            case "ET.VAR.MNEM.SUB_ESPACIO_FCB_ESPACIO_H.FCB":
//            case "ET.VAR.MNEM.SUB_ESPACIO_FCB_ESPACIO_H.FCB_ESPACIO_COMENTARIO":
//                break;
//                
//            case "ESPACIO_END_ESPACIO_H.ORG.EQU.EXT":
//                break;
//                
//            default:
//                System.out.println(">"+sintax+"<");
//                System.out.print(">>");
//                
//                for(int j=0;j<i;j++){
//                    System.out.print(code[j]);
//                }
//                System.out.print("<<\n");
//                break;
//                
//        }
//            for(int j=0;j<i;j++){
//                lst.write(code[j]);
//            }
//            lst.write("\n");
//        }else {
//            
//            lst.write(cont+":\n");
//            
//        }
//        if(!tmp.isEmpty()){
//            this.Subrut.putAll(tmp);
//        }
//        return Equ;
//    }
    
    public String CharAHexaIMM(String lexer){
        String operando=lexer.substring(2);
        char car=operando.charAt(0);
        operando=Integer.toHexString((int)car);
        return operando.toUpperCase();
    }
    
    
    public String DecAHexaIMM(String lexer,int bytes){
//        int i=lexer.indexOf("#");
        String operando=lexer.substring(1);
        operando=Integer.toHexString(Integer.parseInt(operando));
        if((bytes==1&&Integer.parseInt(operando)<16)||(bytes==2&&Integer.parseInt(operando)<4096)){
            operando="0"+operando;
        }else if(bytes==2&&Integer.parseInt(operando)<256){
            operando="00"+operando;
        }
        
        return operando;
    }

    
    public String localidad(String loci,int a){
        int i=Integer.parseInt(loci,16);
        i=i+a;
        loci=Integer.toHexString(i);
        return loci.toUpperCase();
    }
    
    public String[] CodigoF(String code){
        String[] arr=code.split("@");
        int i=arr.length;

        String[] arr2=new String[i-1];
        
        for(int j=1;j<i;j++){
            arr2[j-1]=arr[j];
        }
        return arr2;
    }
    
    public int tamanio(String[] tokens){
        int j=0;
        while(j<15){
            if(tokens[j]=="LINEA"){
                break;
            }
            j++;
            
        }
        return j;
    }
    
    public String Sintaxis(String[] tokens){
        StringBuffer sb=new StringBuffer();
        int i=0;
        int j=tamanio(tokens);
        String st;
        switch(j){
            case 0: //LINEA
            case 1: // ALGO + LINEA
                st=tokens[0]; //ALGO o LINEA
                break;
            default:
                for(i=0;i<j-1;i++){
                    sb.append(tokens[i]).append("_");
                }
                sb.append(tokens[i]);
                st=sb.toString();
                break;
        }
        if(st.length()>8){
            if(st.substring(st.length()-8).equals("_ESPACIO")){
                st=st.substring(0, st.length()-8);
            }
        }
        return st;
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnArchivo = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAnalizarLex = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnArchivo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnArchivo.setText("abrir archivo");
        btnArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArchivoActionPerformed(evt);
            }
        });

        txtAnalizarLex.setEditable(false);
        txtAnalizarLex.setColumns(20);
        txtAnalizarLex.setRows(5);
        jScrollPane2.setViewportView(txtAnalizarLex);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 21)); // NOI18N
        jLabel1.setText("Compilador MC68HC11");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(94, 94, 94)
                                .addComponent(btnArchivo, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jLabel1)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(btnArchivo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchivoActionPerformed

         
        JFileChooser chooser=new JFileChooser();
        chooser.showOpenDialog(null);
        File archivo=new File(chooser.getSelectedFile().getAbsolutePath());
        this.archivo=archivo;
        
        try {
            Reader lector=new BufferedReader(new FileReader(chooser.getSelectedFile()));
            Hashtable<String,String> sub=subrut(lector);
            Reader lector2=new BufferedReader(new FileReader(chooser.getSelectedFile()));
            analizarLexico(lector2,sub);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnArchivoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnArchivo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea txtAnalizarLex;
    // End of variables declaration//GEN-END:variables
}










