/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Instr{
    
    String opcode;
    int bytes;
    int Opbytes; // del operando
    
    public Instr(String opcode,int bytes,int Opbytes){
        this.opcode=opcode;
        this.bytes=bytes;
        this.Opbytes=Opbytes;
    }
    
    public String getOp(){
        return this.opcode;
    }
    public int getBy(){
        return this.bytes;
    }
    public int getOpBy(){
        return this.Opbytes;
    }
}
